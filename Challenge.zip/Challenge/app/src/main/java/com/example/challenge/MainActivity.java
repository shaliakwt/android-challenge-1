package com.example.challenge;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    boolean Xturn = true;
    TextView turn;
    int [] Xarray = new int[9];
    int [] Oarray = new int[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button zero = findViewById(R.id.button0);
        final Button one = findViewById(R.id.button1);
        final Button two = findViewById(R.id.button2);
        final Button three = findViewById(R.id.button3);
        final Button four = findViewById(R.id.button4);
        final Button five = findViewById(R.id.button5);
        final Button six = findViewById(R.id.button6);
        final Button seven = findViewById(R.id.button7);
        final Button eight = findViewById(R.id.button8);
        Button Reset = findViewById(R.id.Reset);
        turn = findViewById(R.id.textView);

        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zero.setText("");
                one.setText("");
                two.setText("");
                three.setText("");
                four.setText("");
                five.setText("");
                six.setText("");
                seven.setText("");
                eight.setText("");


            }
        });


        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(Xturn) {
                   Xarray[0] = 1;
                   checkXWin();
                   zero.setText("X");
               }  else {
                   Oarray[0] = 1;
                   checkOWin();
                   zero.setText("O");
               }


            }
        });
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(Xturn) {
                   Xarray[1] = 1;
                   one.setText("X");
                   checkXWin();
               }  else {
                   Oarray[1] = 1;
                   checkOWin();
                   one.setText("O");
               }


            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Xturn){
                    Xarray[2] = 1;
                    two.setText("X");
                    checkXWin();
                }  else {
                    Oarray[2] = 1;
                    checkOWin();
                    two.setText("O");
                }


            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(Xturn){
                   Xarray[3] = 1;
                   three.setText("X");
                   checkXWin();
               } else {
                   Oarray[3] = 1;
                   checkOWin();
                   three.setText("O");
               }

            }
        });
         four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Xturn) {
                    Xarray[4] = 1;
                    four.setText("X");
                    checkXWin();
                }   else {
                    Oarray[4] = 1;
                    checkOWin();
                    four.setText("O");
                }


            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(Xturn) {
                   Xarray[5] = 1;
                   five.setText("X");
                   checkXWin();
               } else {
                   Oarray[5] = 1;
                   checkOWin();
                   five.setText("O");

               }
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Xturn) {
                    Xarray[6] = 1;
                    six.setText("X");
                    checkXWin();
                }  else {
                    Oarray[6] = 1;
                    checkOWin();
                    six.setText("O");
                }


            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Xturn){
                    Xarray[7] = 1;
                    seven.setText("X");
                    checkXWin();
                }   else {
                    Oarray[7] = 1;
                    checkOWin();
                    seven.setText("O");
                }


            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Xturn) {
                    Xarray[8] = 1;
                    eight.setText("X");
                    checkXWin();
                }  else {
                    Oarray[8] = 1;
                    checkOWin();
                    eight.setText("O");
                }


            }
        });

    }
    public void checkXWin() {
       Xturn = false ;
       turn.setText("O Turn");
       if(Xarray[0] == 1 && Xarray[1] == 1 && Xarray[2] == 1) {
           Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
       }
        if(Xarray[3] == 1 && Xarray[4] == 1 && Xarray[5] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[6] == 1 && Xarray[7] == 1 && Xarray[8] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[0] == 1 && Xarray[3] == 1 && Xarray[6] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[1] == 1 && Xarray[4] == 1 && Xarray[7] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[2] == 1 && Xarray[5] == 1 && Xarray[8] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[0] == 1 && Xarray[4] == 1 && Xarray[8] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[2] == 1 && Xarray[4] == 1 && Xarray[6] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }

    }
    public  void checkOWin() {
        Xturn = true;
        turn.setText("X Turn");
        if(Oarray[0] == 1 && Oarray[1] == 1 && Oarray[2] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[3] == 1 && Oarray[4] == 1 && Oarray[5] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[6] == 1 && Oarray[7] == 1 && Oarray[8] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[0] == 1 && Oarray[3] == 1 && Oarray[6] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[1] == 1 && Oarray[4] == 1 && Oarray[7] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[2] == 1 && Oarray[5] == 1 && Oarray[8] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Oarray[0] == 1 && Oarray[4] == 1 && Oarray[8] == 1) {
            Toast.makeText(MainActivity.this,"O Has Won!", Toast.LENGTH_LONG).show();
        }
        if(Xarray[2] == 1 && Xarray[4] == 1 && Xarray[6] == 1) {
            Toast.makeText(MainActivity.this,"X Has Won!", Toast.LENGTH_LONG).show();
        }
    }
}